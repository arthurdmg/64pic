﻿<?php error_reporting(0);
ini_set('display_errors', 0); ?>

<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>Account</title>
  </head>
<body style='background-color: #00A0A0;' >

  </table>

<?php

    $account = $_POST['account'];
    $balance = 10;

    include("sql/conf.php"); 


    // In files table count the total number of likes of each user

    // Count the likes of the account
    $query = "SELECT wallet, SUM(likes), COUNT(wallet) FROM 64pic WHERE wallet LIKE '$account'";


    $result = mysqli_query($db, $query);
	
        while ($row = mysqli_fetch_array($result)){

        $likes = $row['1']; 
        $files = $row['2']; 
            
        }

    $query = "SELECT likes, SUM(likes) FROM 64pic";


    $result = mysqli_query($db, $query);
	
        while ($row = mysqli_fetch_array($result)){

        $total = $row['1']; 

        }

    $proportion = ($likes / $total) * 100;

    $proportion = substr($proportion, 0, 4);  // retorna "abcde"
   
    $percent_gains = ($proportion / 100) * $balance;

    $format_percent_gains = substr($percent_gains, 0, 4);  // retorna "abcde"


echo "
<br><div align='center'>
<table width='40%' style='border: 1px solid #999;border-radius: 12px 12px 12px 12px; background-color: #ffffff;'>
    <tr>
      <td> 



<div align='center'>    <table class='main' width='30%' style='border:none;'>
    <tr>
      <td>
        <br>
        <form action='account.php' method='post'>
          <table width='100%'>
            <tr>
              <td width='80%'>
                <input type='text' name='account' maxlength='600'>
              </td>
              <td width='20%'>
                <input type='submit' style='padding: 4%;' name='submit' value='Verificar'>
              </td>
            </tr>
          </table>
        <div id='field'></div>
        </form>
      </td>
    </tr>
  </table>
</div>


        <div align='center' style='letter-spacing: 2px;'>
        <br>
        <br>

          Conta <br>
          <b>$account</b><br><br>

          Total de likes <br>
          $likes  <br><br>

          Arquivos <br>
          $files  <br><br>

          Total de likes do servidor <br>
          $total  <br><br>

          Receita do servidor<br>
          $balance R$<br><br> 
          
          Porcentagem de participação <br>
          $proportion%<br><br>

          Ganhos <br>
          $percent_gains  <br><br>


          Saldo:      

          <h1>$format_percent_gains R$</h1>          
      
      <br>
</td>
</tr>
</table>";
 	

?>

</div>
<br>
<div align='center'>
<a href='index.php'><u>Voltar</u></a>
</div>
<br>
</body>

</html>
