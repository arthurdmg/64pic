<?php

$host_to_send = 'http://pic64.rf.gd/base64_sql_ip.php';

$root = "send_files";

$crypto_name = "Ethereum";

$wallet = "";

$category = "porn";

$redirect = "";

foreach (glob("$root/*") as $picture){



    $image = $picture;
    $type = pathinfo($image, PATHINFO_EXTENSION);
    $data = file_get_contents($image);

    $data_uri = 'data:image/' . $type . ";base64;$crypto_name;$wallet," . base64_encode($data);

    $chunk_size = 1000;

    $hash = sha1_file($image); 

    $chunk = "";

        for ($x = 0; ; $x++){

            $chunk_start = $chunk_size * $x;

            $temp = substr($data_uri, $chunk_start, $chunk_size);

            $chunk = $chunk . $temp;

            $send = file_get_contents("$host_to_send?hash=$hash&base64=$temp");

            if($temp == ""){break;}

        }

$close_file = file_get_contents("$host_to_send?hash=close&base64=close&wallet=$wallet&category=$category&redirect=$redirect");

echo $hash . '<br>';

echo "<img src='$chunk'> <br><br>";

}

?>
