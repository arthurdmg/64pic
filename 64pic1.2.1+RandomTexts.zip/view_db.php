<div align='center'>

<?php

$id = $_GET['id'];  

include("sql/conf.php");

$folder = "files";
	
$query = "SELECT * FROM 64pic WHERE id = '$id'";

$result = mysqli_query($db, $query);

while ($row = mysqli_fetch_array($result)){
 
      $img = $row['3'];

      echo "<img src='$img'>";

}

echo "<br><br><a href='view_db.php?id=" . ($id - 1) . "'>Prev</a>&nbsp;&nbsp;&nbsp;&nbsp;";

echo "<a href='view_db.php?id=" . ($id + 1) . "'>Next</a>";


?>