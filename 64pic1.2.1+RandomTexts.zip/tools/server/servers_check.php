<?php error_reporting(0);

/*/
Script for find available web servers

/*/

function ip() {
    $ip = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ip = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ip = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ip = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ip = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ip = getenv('REMOTE_ADDR');
    else
        $ip = 'none';
    return $ip;
}

// Default only for the log.txt
function is_online($url) {
   $curl = curl_init($url);
   curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
   curl_setopt($curl,CURLOPT_HEADER,true);
   curl_setopt($curl,CURLOPT_NOBODY,true);
   curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);

   //get answer
   $status = curl_exec($curl);

   curl_close($curl);
   if ($response) return true;
   return false;
}

    $day = date("d");

    $month = date("m");

    $year = date("y");



    
    $date = $year . '-' . $month . '-' . $day;

    $chars = array ('<', '>', "'", '"', '$', '=', '*', '\n');

    $ip = ip();  

    $status = "offline"; 

    $ports = array('80', '8080', '8090', '8000', '123456');

    $total_ports_number = 4;

    include("../../sql/conf.php");

    $type = 'http://'; 


for ($y = 0; $y < 2; $y++){

    if ($y > 0){$type = 'https://';}

    for ($x = 0; $x < $total_ports_number; $x++){
    
        $url_full = $type . $ip . ":" . $ports[$x];
        $server_check = file_get_contents($url_full);
        
        // Clean up javascript code from html page
        $server_check = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', "", $server_check);
        
        // Clean up html tags
        $server_check = strip_tags($server_check);

        // Size limit per page
        $server_check = substr($server_check, 0, 2000); 

        // Clean up break lines
        $server_check = preg_replace('/\s+/', ' ', $server_check);
 
        // Clean up undesired chars 
        $server_check = str_replace($chars, "", $server_check);    

        if($server_check){     
             
             $query = "INSERT INTO servers (url, content, date) VALUES ('$url_full', '$server_check', '$date')";

             mysqli_query($db, $query);

                 if ($hide_status != 'true'){ 
                     echo "$url_full online" . "</br>";         
                 }

             $status = "online";
         }  
    }
  
}


   if ($hide_status != 'true'){ 
       echo "You are " . $status;         
   }


?>

