<?php

/*/
Script for show web servers 

/*/

   include("../../sql/conf.php");

   $query = "SELECT * FROM servers ORDER BY date DESC LIMIT 0, 1500";
   $result = mysqli_query($db, $query);

   while ($row = mysqli_fetch_array($result)){
  
       $url = $row['1'];
       echo $url . '</br>';

   }

?>

