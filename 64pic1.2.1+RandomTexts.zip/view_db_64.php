<?php

$id = $_GET['id'];  

include("sql/conf.php");

$folder = "files";
	
$query = "SELECT * FROM 64pic WHERE id = '$id'";

$result = mysqli_query($db, $query);

while ($row = mysqli_fetch_array($result)){
 
      echo $row['3'];

}

//echo "<br><br><a href='view_db_64.php?id=" . ($id - 1) . "'>Prev</a>&nbsp;&nbsp;&nbsp;&nbsp;";

//echo "<a href='view_db.php?id=" . ($id + 1) . "'>Next</a>";


?>