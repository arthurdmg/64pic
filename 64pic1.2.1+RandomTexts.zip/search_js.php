﻿<?php error_reporting(0); ?>

<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>64pic</title>
  </head>
<body>

<div align='center'>
        <form action="search.php" method="post">

                <input type="text" name="search" style="padding: 1%;" >

                <input type="submit" style="padding: 1%; background-color: #DDDDDD;" name="submit" value="Category">

        </form>
</div>

<table width='100%'>
  <tr>
    <td width='50%' valign='top'>

        <div id='H'></div>

    </td>
    <td width='50%' valign='top'>

 <div id='E'></div>

    </td>

  </tr>
</table>

     

<?php

$home = 'search_js.php';

$search = $_POST["search"];

if ($_POST["search"] == ""){$search = $_GET['search'];}

$unallowed_chars = array ('<', '>', "'", '"', '$', '*', ",");

$search = str_replace($unallowed_chars, "", $search); 

include("sql/conf.php");

$start = $_GET['start'];  
	
if (!$start){$start = 0;}

$limit = 20;

$ini = $start * $limit;

$query = "SELECT * FROM 64pic WHERE category LIKE '%$search%' ORDER BY likes DESC LIMIT $ini, $limit";

$result = mysqli_query($db, $query);

$count = "";

$inner_style = 'W3';

echo "<script>var biggestSide;img = new Image(); var height_count = 0; var width_count = 0; var count = 0;</script>";

echo "<div align='center'><table width='50%'><tr><td>";

    while ($row = mysqli_fetch_array($result)){
 
      $count++;
      $hash = $row['1'];
      $img = $row['3'];
      $redirect = $row['8'];

      if($img == ""){continue;}

      $like = "<a href='#' onClick='likeFrame(" . '"' . $hash . '"' .  ")'><img src='symbols/thumb_up.png'></a>"; 
      $deslike = "<a href='#' onClick='deslikeFrame(" . '"' . $hash . '"' .  ")'><img src='symbols/thumb_down.png'>";     


      if($redirect != ""){

          $img_link = '"' . "<a href='sql/like.php?file=$hash' target='_blank'><img src='$img' width='100%'></a>" . '"';

      } else {

          $img_link = '"' . "<a href='sql/like.php?file=$hash' target='_blank'><img src='$img' width='100%'></a>" . '"';

      }


$img_link_square = '"' . "<a href='$img' target='_blank'><img src='$img' width='150px'  onClick='likeFrame($hash);'></a>" . '"';

if ($inner_style == 'W1'){$inner_style = 'W2';}

if ($inner_style == 'W2'){$inner_style = 'W3';}

if ($inner_style == 'W3'){$inner_style = 'W1';}

echo "<script>

count++;

img.src = '$img';

if (count == 1){

document.getElementById('H').innerHTML += $img_link + '<br>';

} else {    

document.getElementById('E').innerHTML += $img_link_square;

}

</script>";        
       
      
}

echo "</td></tr></table><div>";

      if ($count == ""){echo "<br><br<br><br><br><br>No results!";}


echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

} 

?>
<br>
<br>
<div align='center'>
<a href='search.php' style='font-size: 12px;'><u>simple version</u></a> &nbsp; 
</div>
<br>