﻿<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>64pic</title>
  </head>
<body>

<table width="100%">
<tr>
<td>
Imagem meramente ilustrativa<br>
<img src='logos/background2.jpg' width='100%'><br><br>
<div align='center'>
<img src='logos/1.png'>
</div>
</td>
</tr>
</table>


<table width="100%" style="padding-left: 15%; padding-right: 15%;">
  <tr>
    <td> 
      <br>
      <div align='center' style='letter-spacing: 2px;'>O 64pic busca rentabilidade investindo em NFTs e armazenamento de imagens</div>
      <br>


<div align='center'>
<a href='tools/server/server.php'><u>Indexar meu servidor</u> / <a href='tools/server/servers.php'><u>Lista de servidores</u></a> / <a href='tools/server/search_servers.php'><u>Pesquisar servidor</u></a> / <a href='tools/converter_sql.php'><u>Converter imagem para base64</u></a> / <a href='files/index.php'><u>Galeria</u></a>
</div>

<br><br><br>
<h1>Conceito</h1>
<p style='letter-spacing: 2px; text-align: justify;'>
Um dos objetivos da nossa moeda é a venda, compra e produção de NFTs.
Ao investir em uma obra de arte digital você adquire uma porcentagem dela. Ou seja, ao invés de a obra ter um único dono ela terá vários sócios investidores, assim quando a obra for vendida o lucro dela será repartido entre os sócios que investiram nela.
Nós temos quatro obras de artes prontas e a disposição de investimento produzidas por nosso artista oP3m! que são a "Perfect Solitude", "Casadevall", "Rain drops" e "The totem" que serão disponibilizadas nas plataformas de NFT quando atingirem investimentos o suficiente.

<br>


<table>
  <tr>
    <td width='25%' valign='top'>
    
    <div align='center'>Rain drops</div>

    <a href='auction/8e06dc662c2780918bfa89c80f049f5ca4f3586c.jpg' target='_blank'><img src='auction/8e06dc662c2780918bfa89c80f049f5ca4f3586c.jpg' width='100%'></a>

    <br>
      

    </td>

    <td width='25%' valign='top'>
    
    <div align='center'>Casadevall tribute</div>

    <a href='auction/f2fe965943366f86731d6ed3e1b3b591cadf4280.jpg' target='_blank'><img src='auction/f2fe965943366f86731d6ed3e1b3b591cadf4280.jpg' width='100%'></a>

    <br>


    </td>

    <td width='25%' valign='top'>
    
    <div align='center'>The Totem</div>

    <a href='auction/911942144c75b8c92b997acb22ca8d605f2f439c.jpg' target='_blank'><img src='auction/911942144c75b8c92b997acb22ca8d605f2f439c.jpg' width='100%'></a>

    <br>   

    </td>

    <td width='25%' valign='top'>
    
    <div align='center'>Perfect Solitude</div>

    <a href='auction/06cb6c48887fa4bcd630ce0ec5436f73654cf36d.jpg' target='_blank'><img src='auction/06cb6c48887fa4bcd630ce0ec5436f73654cf36d.jpg' width='80%'></a>

    <br>  

    </td>


  </tr>
</table>

</p>

     <h1>Armazenamento</h1>

     <p style='letter-spacing: 2px; text-align: justify;'>
         O 64pic foi pensado para ser o projeto mais flexível o possivel. Essa é a sua principal filosofia e ideal, proporcionar ampla liberdade ao usuário  de compartilhar as suas  fotos e mídias construindo a sua própria rede ou utilizando o nosso projeto como base. Assim sendo, nós convencionamos a maneira como os arquivos serão salvos e seus atributos mas não como eles estarão distribuídos em alguma blockchain específica. Ou seja, cada arquivo é como um registro de um banco de dados e o banco de dados são os próprios arquivos distribuidos. Foi desenvolvido do zero uma maneira peculiar de enviar os arquivos via base64, permitindo que mesmo dispositivos com portas bloqueadas pelo provedor possam baixar e enviar múltiplos arquivos, embutindo em cada acesso ou requisição de um site os pedaços dos arquivos, assim como o endereço da carteira Ethereum ou chave PIX do usuário, para que possa receber recompensas do servidor de acordo com o número de likes que seu arquivo receber.

     </p>

     <br>
      <h1>Como funciona?</h1>

      <table width="100%">
        <tr>
          <td width='30%'>

            <div align='center'>
              <img src='logos/e1.png' width='100%'>
            </div>

          </td>
          <td width='5%'> </td>
          <td width='60%' valign='top' style="text-align: justify;">

Cada imagem enviada é associada com a chave PIX ou carteira de criptomoeda Ethereum do usuário. Quanto mais as suas imagens forem curtidas maior será o seu percentual de ganho de acordo com a receita total da rede. 
          </td>
        </tr>
      </table>

<h1>White paper (resumo)</h1>

<br>
<div style='padding-left: 20px; text-align: justify;'>
&nbsp;&nbsp;&nbsp;&nbsp; O armazenamento de imagens na internet exige Hds ou a hospedagem em que elas estão armazenadas e isso representar um fator com que a rede lida e equaciona. A obtenção do hash das imagens, ou seja, da sua identificação única e a conversão dessas imagens para base64 também exigem tempo, energia elétrica e poder computacional que do mesmo modo representam custos para a rede. Uma vez que as imagens foram convertidas para base64 qualquer dispositivo pode enviá-las para múlltiplos servidores, evitando os bloqueios ou limitações da rede wi-fi, hardware ou das portas disponibilizadas pelo provedor, assim um nodo pode funcionar no computador ou celular mais simples, uma vez que não são necessárias "portas abertas" ou um servidor de fato, mas apenas envios via URL com os pedaços em base64. Em tese, as imagens podem ser associadas a qualquer criptomoeda existente, assim em seu cabeçalho haverá o endereço e a criptomoeda que aquele usuário escolheu para receber e associar com a imagem que enviou para o servidor. Cada servidor, portanto, de acordo com a receita que possui irá gratificar os usuários que tiverem as imagens mais curtidas, já descontando sua taxa de operação, porque em cada imagem está embutida o endereço da carteira do usuário que enviou a imagem. Por fim, há os custos e os gastos no desenvolvimento do projeto, do design, mídias sociais etc. Quando você investe no projeto não está investindo apenas em um modelo isolado mas em uma idéia com potencial ilimitado que visa tornar mais eficiente e produtiva a nossa experiencia digital.
</div>
<br>
            



  <table width="100%" style="padding-left: 15%; padding-right: 15%; text-align: justify;" border="0">
    <tr>
      <td> 

      <h1>URI</h1>

      <p style='letter-spacing: 2px;'>Nosso sistema utiliza algumas variáveis e convenções para você utilizar<br><br>

      <p style='letter-spacing: 2px;'>1. <b>hash</b> : Define o nome que a imagem terá no sistema. </p><br>

      <p style='letter-spacing: 2px;'>2. <b>base64</b> : Essa variável é responsável por enviar os pedaços do arquivo ao servidor</p><br>

      <p style='letter-spacing: 2px;'>3. <b>wallet</b> : O endereço da carteira ou chave do usuário</p><br>

      <p style='letter-spacing: 2px;'>4. <b>category</b> : A categoria da imagem ou do grupo de imagens</p><br>

      <p style='letter-spacing: 2px;'>5. <b>redirect</b> : Ao clicar em uma imagem o usuário será redirecionado para alguma outra página</p><br>

     <br>
 
     </td>
  </tr>
</table>

<br>
<br>

<div align='center'><a href='index.php'>voltar</a></div>
<br>
<br>

  </body>
</html>