<?php

$limit = 100;

for ($x = 0; $x < $limit; $x++){

$url = "http://localhost/post/view_db_64.php?id=$x";

$get_url = file_get_contents("$url");

if(file_exists("files/base64/$x")){continue;}

$file_base64 = fopen("files/base64/$x", "w");
fwrite($file_base64, $get_url);
fclose($file_base64); 

    //$query = "INSERT INTO 64pic (base64) VALUES ('$get_url')";

    //$result = mysqli_query($db, $query); 
}


?>