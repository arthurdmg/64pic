﻿<?php error_reporting(0);

$host = "http://localhost/post/";

$id = $_GET['id'];  
	
if (!$id){$id = 0;}

$c = 0;

foreach (glob("files/*") as $picture){


if ($picture == "index.php" or $picture == "index_full.php"){continue;}

    if ($c == $id){

        echo "$host" . "$picture";

    }

$c++;
}


?>