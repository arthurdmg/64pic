<?php error_reporting(0); ?>

<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="icons/7.png">
    <link rel="stylesheet" href="default3.css">
    <script src="js/default.js"></script>

    <title>Home</title>
  </head>

  <body>

<?php
if(isset($_POST["submit"]) and $_POST["url"]) {

$url = $_POST["url"];
$name = $_POST["name"];
$tags = $_POST['category'];
$desc = $_POST['description'];
$size = $_POST['size'];
$user = $_POST['creator'];
$add = $_POST["add"];

$unallowed_chars = array ('<', '>', "'", '"', '$', '*');

$unallowed_chars2 = array ('<', '>', "'", '"', '$', '*', ",");

$url = str_replace($unallowed_chars, "", $url); 
$name = str_replace($unallowed_chars, "", $name); 
$tags = str_replace($unallowed_chars, "", $tags); 
$desc = str_replace($unallowed_chars, "", $desc); 
$size = str_replace($unallowed_chars, "", $size); 
$user = str_replace($unallowed_chars, "", $user); 
$add = str_replace($unallowed_chars2, "", $add); 

include("sql/link_conf.php");


// Check if the url exists and get urls field values
$query = "SELECT * FROM instances WHERE url LIKE '$url'";


$result = mysqli_query($db, $query);

    while ($row = mysqli_fetch_array($result)){
 
    $db_url = $row[4];
    $db_urls = $row[18];

    }

// Insert url case it don't exists
if ($db_url == ""){

    $day = date("d");

    $month = date("m");

    $year = date("y");



    
    $date = $year . '-' . $month . '-' . $day;

    $query = "INSERT INTO instances (name, user, url, description, date, size, categories, urls) VALUES ('$name', '$user', '$url', '$desc', '$date', '$size', '$tags', '$add')";

    $result = mysqli_query($db, $query);

    echo "URL inserted with success!";

} else {


$link_list = explode(",", $db_urls);

$list_size = count($link_list);

$unique = true;

// Check if urls field has unique values 
for ($i = 0; $i < $list_size; $i++){

    if ($link_list[$i] == $add){
        $unique = false;
    } 
}

// Update only urls field
if ($url != $add){

    if ($unique){

        if ($db_urls == ""){$delimiter = "";}else{$delimiter = ",";}

        $final_urls = $db_urls . $delimiter . $add;

        $query = "UPDATE instances SET urls = '$final_urls' WHERE url = '$url'";

        $result = mysqli_query($db, $query);

        echo "</br>URL updated with success!";

    } 
}


}}

include("search.php");

?>
   