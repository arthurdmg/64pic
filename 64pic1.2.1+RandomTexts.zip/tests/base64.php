<?php

$hash = $_GET['hash'];
$base64 = $_GET['base64'];

$folder = "files";

$base64_file = fopen("$folder/$hash", "a");
fwrite($base64_file, $base64);
fclose($base64_file);

?>
