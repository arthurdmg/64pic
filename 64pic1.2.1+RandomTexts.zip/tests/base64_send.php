<?php

$host_to_send = 'http://localhost/post/base64_no_session_ip.php';

$image = '1.jpg';
$type = pathinfo($image, PATHINFO_EXTENSION);
$data = file_get_contents($image);

$data_uri = 'data:image/' . $type . ';base64,' . base64_encode($data);

$chunk_size = 1000;

$hash = sha1_file($image); 

$chunk = "";

for ($x = 0; ; $x++){

    $chunk_start = $chunk_size * $x;

    $temp = substr($data_uri, $chunk_start, $chunk_size);

    $chunk = $chunk . $temp;

    $send = file_get_contents("$host_to_send?hash=$hash&base64=$temp");

    if($temp == ""){break;}

}

$close_file = file_get_contents("$host_to_send?hash=none&base64=none");

echo $hash . '<br><br>';

echo "<img src='$chunk'/>";

echo '<br><br>' . $chunk;

?>
