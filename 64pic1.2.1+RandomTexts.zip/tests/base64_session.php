<?php

/*/

Script for receive and save a image via base64

  - Close a file if the hash name changes (using session)
  - Create a temporary files to put together the GET chunks
  - Avoid overwrite final files

/*/

session_start(); 

$_SESSION['hash_temp'];
$hash = $_GET['hash'];

$base64 = $_GET['base64'];

$_SESSION['hash_temp'];

$folder = "files";

//Avoid the users use the symbol reserved for temporary files
$hash = str_replace("_","",$hash);


//$base64 = str_replace(" ","+",$base64);

//Already exist files cannot be overwrite
if(file_exists("$folder/$hash")){

    echo "File already exists.";

}else{

    //Open and write temporary file
    $base64_file = fopen("$folder/tmp_$hash", "a");
    fwrite($base64_file, $base64);
    fclose($base64_file);

    $temp = 'tmp_' . $_SESSION['hash_temp'];
    $perm = $_SESSION['hash_temp'];

    //If the hash name changes the file is renamed and cannot be more overwritten
    if($_SESSION['hash_temp'] != $hash and $_SESSION['hash_temp'] != ""){
   
            echo "Previous file: $perm";
            rename("$folder/$temp", "$folder/$perm");

    }
}

//Catch the last value of hash
$_SESSION['hash_temp'] = $hash;



?>
