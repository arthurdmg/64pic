base64 -> pictures database
iyp -> links database



Import base64 and iyp to your database