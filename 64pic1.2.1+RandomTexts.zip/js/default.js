var clicked = false;
var host = "http://localhost/post/";

function likeFrame(url){

        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", host + 'sql/like.php?url=' + url);
        ifrm.style.width = "0px";
        ifrm.style.height = "0px";
        ifrm.setAttribute("hidden", true);

        document.body.appendChild(ifrm);

        window.alert("Liked!");
}

function deslikeFrame(url){

        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", host + 'sql/deslike.php?url=' + url);
        ifrm.style.width = "0px";
        ifrm.style.height = "0px";
        ifrm.setAttribute("hidden", true);

        document.body.appendChild(ifrm);        

        window.alert("Desliked!");
}    

function likeFramelk(url){

        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", host + 'sql/likelk.php?url=' + url);
        ifrm.style.width = "0px";
        ifrm.style.height = "0px";
        ifrm.setAttribute("hidden", true);

        document.body.appendChild(ifrm);

        window.alert("Liked!");
}

function deslikeFramelk(url){

        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", host + 'sql/deslikelk.php?url=' + url);
        ifrm.style.width = "0px";
        ifrm.style.height = "0px";
        ifrm.setAttribute("hidden", true);

        document.body.appendChild(ifrm);        

        window.alert("Desliked!");
}    



function showFields(){

  if(clicked){
  document.getElementById("field").innerHTML = "";
  clicked = false;
  }else{
  document.getElementById("field").innerHTML = " <input type='text' name='url' placeholder='URL' maxlength='600'><input type='text' name='name' placeholder='Name' maxlength='100'><input type='text' name='description' placeholder='Description' maxlength='200'><input type='text'name='category' placeholder='Category' maxlength='50'><input type='text'name='size' placeholder='Size' maxlength='6'><input type='text'name='creator' placeholder='Bitcoin wallet' maxlength='50'><input type='text'name='add' placeholder='Additional URL' maxlength='600'><input type='submit' name='submit' value='Insert'>";
  clicked = true;  
  }
}