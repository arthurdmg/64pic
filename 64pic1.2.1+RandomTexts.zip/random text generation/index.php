<a href='random.php'>random</a>
<a href='random_1.php'>random2</a>
<a href='random_2.php'>random3</a>