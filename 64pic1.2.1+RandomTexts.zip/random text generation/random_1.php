<?php

$c = array('b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z');
$v = array('a', 'e', 'i', 'o', 'u');

for ($i = 0; $i < 1000; $i++){

    $random_c = rand(0, 20);
    $random_v = rand(0, 4);
    $random_space = rand(0, 100);

    if ($random_space > 50){$space = ' ';} else {$space = '';} 
   
    echo $c[$random_c] . $space . $v[$random_v];    
}

?>