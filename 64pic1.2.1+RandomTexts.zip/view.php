<?php

$id = $_GET['id'];  

include("sql/conf.php");

$folder = "files";
	
$query = "SELECT * FROM 64pic WHERE id = '$id'";

$result = mysqli_query($db, $query);

while ($row = mysqli_fetch_array($result)){
 
      $img = $row['3'];

      echo "<img src='$img'>";

}

?>