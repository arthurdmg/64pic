﻿<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>64pic</title>
  </head>
<body>

<br>

<div align='center'>
<table width="80%">
  <tr>
    <td> 

      <a href='index.php'><img src='logos/2.png' width='30px'></a>
      <i>Small PHP tools</i>

      <div align='right'>Lang: <a href='index.php'>Eng</a> | <a href='index_pt.php'>Pt</a></div>  </br> </br>

      <a href='groups.php'>Chat</a></br>
      Send and receive simple messages in groups</br></br>

      <a href='search_js.php'>Images</a></br>
      Image Search</br></br>

      <a href='files/index.php'>File upload</a></br>
      Upload files</br></br>

      <a href='videos/index.php'>Video upload</a></br>
      Upload videos</br></br>
      
      <a href='random text generation/index.php'>Random text generator</a></br>
      Create aleatoric texts</br></br>

      </br></br>

      <a href='https://www.paypal.com/donate/?hosted_button_id=JTC7AUY6PLDQW' target='_blank'>Donatios</a></br>
      <a href='terms.php'>Terms of use</a></br>
      <a href='64pic1.2.1.zip'>Sourcecode</a> <a href='64pic1.2.1+RandomTexts.zip'>[with Random Texts]</a></br>

      </br> </br>
  
      <i>Hall oracle - 2022</i> 

    </td>
  </tr>
</table>
</div>

  </body>
</html>
