WWW and INFO icons from FatCow under
a Creative Commons Attribution 3.0 License.
http://creativecommons.org/licenses/by/3.0/us/