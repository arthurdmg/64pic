﻿<div align='center'>

<?php error_reporting(0); ?>


<form action="index.php" method="POST">

    <input type="text" name="search">    
    <input type="submit" value="Search" />

</form>

<form enctype="multipart/form-data" action="index.php" method="POST">

    Select video <input name="video" type="file" />
    Select thumbnail <input name="thumb" type="file" />
    
    <input type="submit" value="Send" />
</form>

<?php

$file = basename($_FILES["video"]["name"]);

$target_dir = "videos/";

$target_file = $target_dir . basename($_FILES["video"]["name"]);

$name = basename($_FILES["video"]["name"]);

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

$allow_upload = 1;

if($imageFileType != "mp4") {
  $allow_upload = 0;
}

if(file_exists($uploadfile)){
  echo "Sorry file exists!<br>";
  $allow_upload = 0;
}

if($allow_upload){
if (move_uploaded_file($_FILES["video"]["tmp_name"], $target_file)) {
    echo "Video uploaded!<br>";
  } else {
    echo "Error<br>";
  $allow_upload = 0;
}}

$file = basename($_FILES["video"]["name"]);

$target_dir = "thumbs/";

$target_file = $target_dir . basename($_FILES["thumb"]["name"]);

$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

$allow_upload2 = 1;

if($imageFileType != "jpg") {
  echo " only allowed jpg thumbnail<br>"; 
  $allow_upload2 = 0;
}

if(file_exists($uploadfile)){
  echo "Sorry file exists!<br>";
  $allow_upload2 = 0;
}

if($allow_upload and $allow_upload2){
if (move_uploaded_file($_FILES["thumb"]["tmp_name"], basename($_FILES["video"]["name"]) . "." . $imageFileType)) {
    echo "Thumbnail uploaded!<br>";
  } else {
    echo "Error<br>";
}}


$start = $_GET['start'];  
	
if (!$start){$start = 0;}

$c = 0;
$limit = 5;
$ini = $start *  $limit;
$end = $ini + $limit;

$entry = 0;

$search = $_POST['search'];

if ($search == ""){$search = $_GET['search'];}


if ($search != ""){

foreach (glob("videos/*") as $picture){


$name = str_replace("$search", "", "$picture");
$name_len = strlen($name);
$entry_len = strlen($picture);

if ($entry_len > $name_len){

    if($entry >= $ini and $entry  < $end){

        echo "<a href='$picture' target='_blank'><img src='../$picture.jpg'></a><br><a href='$picture' target='_blank'>$picture</a><br><br>";

    }

$entry++;

}



$c++;
}}else{


foreach (glob("videos/*") as $picture){


if ($picture == "index.php"){continue;}

    if ($c >= $ini and $c < $end){

        echo "<a href='$picture' target='_blank'><img src='../$picture.jpg'></a><br><a href='$picture' target='_blank'>$picture</a><br><br>";

    }

$c++;
}

}

echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index.php?start=$i&search=$search'>$i/ </a>";
    }

} 


?>

</div>
</div>