<?php

$c = 0;

foreach (glob("pictures/*") as $picture){



$c++;

/*/
if ($c > 5){

$x = rand(100, 800) . "px";
$y = rand(800, 1000) . "px";


} else {


$x = rand(100, 800) . "px";
$y = rand(0, 200) . "px";

}

/*/

if ($c > 3){

$x = rand(10, 80) . "%";
$y = rand(80, 90) . "%";

$ini_size = rand(0, 200) . "px";

} else {


$x = rand(10, 80) . "%";
$y = rand(0, 20) . "%";

$ini_size = rand(0, 400) . "px";
}


//$ini_size = rand(0, 400) . "px";

if ($c == 8){break;}

echo "<img src='$picture' style='position:absolute; top: $x; left: $y; opacity: 0.2;z-index:-5;' width='$ini_size'>";

}  




?>
