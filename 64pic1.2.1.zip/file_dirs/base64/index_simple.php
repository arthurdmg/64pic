﻿<?php error_reporting(0); ?>

<div align='center'>
<?php 

$start = $_GET['start'];  
	
if (!$start){$start = 0;}

$c = 0;

foreach (glob("*") as $picture){


if ($picture == "index.php" or $picture == "index_full.php"){continue;}


    if ($c == $start){

        echo "<a href='$picture' target='_blank'><img src='$picture'></a><br><br>";

    }

$c++;
}

echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='index.php?start=$i'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='index.php?start=$i'>$i/ </a>";
    }

} 

?>