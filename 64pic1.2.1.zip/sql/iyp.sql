-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04-Jun-2022 às 14:30
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `iyp`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `flags`
--

CREATE TABLE `flags` (
  `user` text NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `instances`
--

CREATE TABLE `instances` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `hash` varchar(40) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `categories` text DEFAULT NULL,
  `date` date DEFAULT NULL,
  `size` varchar(6) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `flags` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `checked` varchar(3) DEFAULT NULL,
  `url2` varchar(500) DEFAULT NULL,
  `url3` varchar(500) DEFAULT NULL,
  `url4` varchar(500) DEFAULT NULL,
  `urls` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `likeslk`
--

CREATE TABLE `likeslk` (
  `user` text NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `instances`
--
ALTER TABLE `instances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`) USING HASH;

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `instances`
--
ALTER TABLE `instances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
