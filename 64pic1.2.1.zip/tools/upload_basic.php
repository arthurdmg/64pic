<?php error_reporting(0); ?>

<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="../default2.css">
</head>
<body>

<?php

echo "<form action='upload.php' method='post' enctype='multipart/form-data'>

  <input type='file' name='fileToUpload' id='fileToUpload'>
  <input type='text' name='category' maxlength='50' placeholder='enter only one category'>
  <input type='submit' value='Upload' name='submit'>
  <input type='submit' value='Find Category' name='submit'>

  &nbsp; <a href='upload.php'> Select a zip file with photos or videos</a>

</form>";

?>

</body>
</html>

<?php

$category = $_POST['category'];

$option = $_POST['submit'];

if ($option != "Find Category"){

//Avoid upload in root folder
$avoid_chars = array("/", "", ".", "*");

$category = str_replace($avoid_chars, "", $category);

if($category == ""){$category = "others";} 

$file = basename($_FILES["fileToUpload"]["name"]);

$target_dir = "categories/$category/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

if(isset($_POST["submit"])) {

if (file_exists("categories/$category")) {
  echo "Sorry, file already exists.";
  echo "</br></br><a href='upload.php'>back to gallery</a>";

  $uploadOk = 0;
}

mkdir("categories/$category");

$filename = explode (".zip",$file);
$filename = $filename[0];

// Allow certain file formats
if($imageFileType != "zip") {
  echo "Sorry, only zip files are allowed with .jpg or .mp4 file extension."; 
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    //echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo " There was an error uploading your file. </br></br>";
    //echo "</br></br><a href='index.php'>back to gallery</a>";
  }
}

}

$ZipFileName = dirname(__FILE__)."/categories/$category/$file";
$home_folder =  dirname(__FILE__)."/categories/$category";

mkdir($home_folder);

$total = file_get_contents("categories/$category/total.txt");

if (!$total){$total = 0;}

$zip = new ZipArchive;
if ($zip->open($ZipFileName ) === true) 
{
/*/
    //make all the folders
    for($i = 0; $i < $zip->numFiles; $i++) 
    { 
        $OnlyFileName = $zip->getNameIndex($i);
        $FullFileName = $zip->statIndex($i);    
        if ($FullFileName['name'][strlen($FullFileName['name'])-1] =="/")
        {
            @mkdir($home_folder."/".$FullFileName['name'],0700,true);
        }
    }
/*/
    //unzip into the folders
    for($i = 0; $i < $zip->numFiles; $i++) 
    { 
        $OnlyFileName = $zip->getNameIndex($i);
        $FullFileName = $zip->statIndex($i);    

        if (!($FullFileName['name'][strlen($FullFileName['name'])-1] =="/"))
        {
            if (preg_match('#\.(jpg|jpeg|gif|png|mp4)$#i', $OnlyFileName))
            {

            $OnlyFileExt = substr($OnlyFileName, -3);
            //$OnlyFileExt = explode(".",  $OnlyFileName);
            //$OnlyFileExt = $OnlyFileExt[1];  

            if(file_exists("$home_folder/$total.$OnlyFileExt")){$total++;continue;}
             
                copy('zip://'. $ZipFileName .'#'. $OnlyFileName , $home_folder."/". "$total.$OnlyFileExt"); 
            } 
        }
    $total++; 
    }

    $zip->close();

    $my_total = fopen("categories/$category/total.txt", "w");
    fwrite($my_total, $total);
    fclose($my_total);


    echo "Uploaded to <a href='categories/$category'>$category</a>";

    //echo "</br></br><a href='index.php'>back</a>";	

} else
{
    //echo "Error: Can't open zip file";
}

unlink("categories/$category/$file");

if($_POST["submit"]){
rmdir("categories/$category/$filename");
}

}

$other_files = "";



if (!file_exists("categories/$category")){echo "</br><h1>Not Found!</h1> Try another...";}else{

    echo "</br>";

$home = "upload.php";
$start = $_GET['start'];
$search = $_GET['search'];

$limit = 20;

if (!$search){$search = $category;}

$folder = "categories/$search/";

for ($x = $start * $limit; $x < ($start * $limit) + $limit; $x++){

    $ext = "";

    if (file_exists("$folder$x.jpg")){$ext = ".jpg";
    echo "<div align='center'><a href='$folder$x$ext' target='_blank'><img src='$folder$x$ext' width='70%'> </a></div>";  
    }

    if (file_exists("$folder$x.png")){$ext = ".png";
    echo "<div align='center'><a href='$folder$x$ext' target='_blank'><img src='$folder$x$ext' width='70%'> </a></div>";  
    }

    if (file_exists("$folder$x.gif")){$ext = ".gif";
    echo "<div align='center'><a href='$folder$x$ext' target='_blank'><img src='$folder$x$ext' width='70%'> </a></div>";  
    }

    if (file_exists("$folder$x.mp4")){$ext = ".mp4";
    echo "<div align='center'><a href='$folder$x$ext' target='_blank'><video controls src='$folder$x$ext' width='70%'> </a></div>";  
    }

}

/*/

    //deprecated - using foreach and without navigation bar 

    foreach (glob("categories/$category/*") as $file){



        $file_type = substr($file, -3);
        $file_type = strtolower($file_type);       

        if ($file_type == "jpg" or $file_type == "png" or $file_type == "gif" or $file_type == "peg"){
              
            echo "<div align='center'><a href='$file' target='_blank'><img src='$file' width='70%'> </a></div>";       
   
        }else{

            $other_files_name = explode ("/", $file);

            $other_files_name = $other_files_name[2];

            $other_files = $other_files . "<a href='$file' target='_blank'>$other_files_name/ </a>";
        }

    }


/*/
}

echo "<br><div align='center'>";


if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

} 

echo "</div>";
?>