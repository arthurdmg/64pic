<?php

/*/
Script for avoid spam protecting user's IP with hash

/*/

function ip() {
    $ip = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ip = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ip = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ip = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ip = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ip = getenv('REMOTE_ADDR');
    else
        $ip = 'none';
    return $ip;
}

    // Max one addition per hour    
    $addition_interval = date('h');  

    $cleanup_interval = date('s');

    $ip = ip();

    $ip_hash = sha1($ip); 

    $ip_hash_time = $ip_hash . $addition_interval;

    // Check and write
    if(file_exists("ip/$ip_hash_time")){
        echo "</br><div align='center'>You have reached the hour limit. Buy a <a href='#' target='_blank'>premium account</a></div>";
        $allow_upload = "no";

    } else {   
        
        $file = fopen("ip/$ip_hash_time", 'w');
        fwrite($file,"");

        fclose($file);

    }

    /*/ 

    Clean up the all the hashes in an arbitrary time
        
       Hour with seconds or minute with seconds are good for the reset time don't collide with the user's interval restrictions.
       Intervals with only seconds allow the users ever reset the system if anyone insert anything.
       Intervals with only hours allow the user flood ever in this time interval of hour.
 

    /*/

    if($addition_interval == "10" and $cleanup_interval == "10"){
   
        foreach (glob("ip/*") as $ips){


        unlink($ips);
        }

    }



?>

