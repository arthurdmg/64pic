<?php error_reporting(0); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Search</title>
  <link rel="icon" href="../icons/7.png">
  <link rel="stylesheet" href="../default2.css">
</head>

<div align='center'><table width='80%'><tr><td>

<body>

<?php


/*/
Script for queries in database

/*/


$search = $_GET['search'];

$chars = array ('<', '>', "'", '"', '$', '=', '*');

$search = str_replace($chars, "", $search); 

$home = "search_servers.php";
   
echo "<div align='center'><form action='$home?search=$search' method='GET'>
     <input type='text' name='search' placeholder='Category'>
     <input type='submit' style='background-color:#AE0EEE;;color: #EEEEEE;' value='  Search  '> 
     </form></div></br>";

include("../../sql/conf.php");

   if($_GET['search']){
   
   //light version
   //$query = "SELECT * FROM instances WHERE '$search' IN (name, url, categories, description) ORDER BY value DESC LIMIT 0, 100";

   $query = "SELECT * FROM servers WHERE content LIKE '%$search%'";

   $result = mysqli_query($db, $query);
 
   while ($row = mysqli_fetch_array($result)){

       $id = $row['0'];
       $url = $row['1'];
       $content = $row['2'];
       $date = $row['3'];

       $content = str_replace($chars, " ", $content); 
     
       echo "<a href='$url' target='_blank'>$url</a></br></br><i>$content ...</i> $date<hr></hr>";
    }
}

?>

</td></tr></table></div>

</body>

</br>

<div align='center'><i><a href='../index.php' style='text-decoration: nono; color: #555555;''>Home</a></i></div>

</html>
