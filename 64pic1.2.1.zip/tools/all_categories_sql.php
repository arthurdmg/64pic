<div style='letter-spacing: 2px; text-align: justify;'>

<?php

    foreach (glob("categories/*") as $category){



        $current = explode("/", $category);
        $current_category = $current[1];

        echo "<a href='converter_sql.php?start=0&search=$current_category'>$current_category </a> / ";
    }

?>