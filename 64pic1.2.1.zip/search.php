<?php error_reporting(0); ?>

<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>64pic</title>
  </head>
<body>

<br>


<div align='center'>
    <form action="search.php" method="post">
        <input type="text" name="search" style="padding: 1%;" >
        <input type="submit" style="padding: 1%;" name="submit" value="Category">
    </form>
</div>

<form action="link_add.php" method="post">
    <a href="#" onClick="showFields()">+ Insert Link</a>  
    <div id="field"></div>
</form>


<?php

include("link_search.php");

$search = $_POST["search"];

if ($_POST["search"] == ""){$search = $_GET['search'];}

$unallowed_chars = array ('<', '>', "'", '"', '$', '*', ",");

$search = str_replace($unallowed_chars, "", $search); 

include("sql/conf.php");

$start = $_GET['start'];  
	
if (!$start){$start = 0;}

$limit = 20;

$ini = $start * $limit;
$end = $ini + $limit;

$query = "SELECT * FROM 64pic WHERE category LIKE '%$search%' ORDER BY likes DESC LIMIT $ini, $limit";

$result = mysqli_query($db, $query);

$count = "";

echo "<div align='center'><table width='50%'><tr><td>";

    while ($row = mysqli_fetch_array($result)){
 
      $count++;
      $hash = $row['1'];
      $img = $row['3'];
      $redirect = $row['8'];

      if($img == ""){continue;}

      if($redirect != ""){

          echo "<a href='$redirect' target='_blank'><img src='$img' width='100%'></a><br>";

      } else {

          echo "<a href='$img' target='_blank'><img src='$img' width='100%'></a><br>";

      }
      

      echo " <a href='#' onClick='likeFrame(" . '"' . $hash . '"' .  ")'><img src='symbols/thumb_up.png'></a> "; 
      echo " <a href='#' onClick='deslikeFrame(" . '"' . $hash . '"' .  ")'><img src='symbols/thumb_down.png'></a><br><br>";  

           
      //echo "<a href='#' onClick='likeFrame()'> like</a><br>";
      

    }
echo "</td></tr></table><div align='center'>";

      if ($count == ""){echo "<br><br<br><br><br><br>No pictures!";}


echo "<div align='center'></br></br></br></br>";

if ($start < 19){

    for ($i = 0; $i < 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

}else{

    for ($i = $start; $i < $start+ 20; $i++){
     
        echo "<a href='$home?start=$i&search=$search'>$i/ </a>";
    }

} 

?>

<div id="ifrm">