<?php

$folder = "files";

$file_content = file_get_contents('');

//$file_content = str_replace(' ', "+", $file_content);

echo "<img src='$file_content'>";

//echo $file_content;

?>
