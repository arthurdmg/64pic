﻿<?php error_reporting(0);?>

<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>Microchat <?php $group = $_POST['group']; echo ":: $group"; ?></title>
  </head>
<body style='background-color: #00A0A0;' >

<?php

$message = $_POST['message'];

$group = $_POST['group'];

?>

<br><div align='center'>
<table width='98%' style='border: 1px solid #999;border-radius: 12px 12px 12px 12px; background-color: #ffffff; letter-spacing: 5px; padding: 1%;'>
  <tr>
    <td> 
      <form action='groups.php' method='POST'>
      <br>
<div align='center'>
     Message: <input type='text' name='message' maxlength='50'>
     Group: <input type='text' name='group' maxlength='100' value='<?php echo $group; ?>'>
     <input type='submit' name='submit' value='Send' style='background-color: #EEEEEE;'>
</div>
     </form>
     <br><br>    

<?php 

function ip() {

    $ip = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ip = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ip = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ip = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ip = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ip = getenv('REMOTE_ADDR');
    else
        $ip = 'none';
    return $ip;
}

$ip = ip();

$ip_hash = sha1($ip);

$folder = "groups";

    $day = date("d");

    $month = date("m");

    $year = date("y");



    $hour = date('G');
    $min = date('i');
    $sec = date('s');    

    $date = $day . '/' . $month . '/' . $year . ' - ' . $hour . ':' . $min . ':' . $sec . ' | ';

if (!$group){$group = 'random';}

if ($message != ""){

$write = fopen("$folder/$group", "a");
fwrite($write, $ip_hash . " " . $date . $message . "<hr></hr><br>");
fclose($write);
}

include("$folder/$group"); 

$filesize = filesize("$folder/$group");
if ($filesize > 2000){unlink("$folder/$group");}    

?>

     <div align='center'><a href='index.php'><u>back</u></a><div>

    </td>
  </tr>
</table>
 	
<?php





?>