<?php

/*/

Script for receive and save a image via base64

  - Close a file if the hash name changes (using session)
  - Create a temporary files to put together the GET chunks
  - Avoid overwrite final files

/*/

$id = $_GET['id'];  

if ($id != ""){

include("sql/conf.php");

$folder = "files";
	
$query = "SELECT * FROM 64pic WHERE id = '$id'";

$result = mysqli_query($db, $query);

while ($row = mysqli_fetch_array($result)){
 
      echo $img = $row['3'];

}
die;
}

function ip() {

    $ip = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ip = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ip = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ip = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ip = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ip = getenv('REMOTE_ADDR');
    else
        $ip = 'none';
    return $ip;
}

$ip = ip();

$ip_hash = sha1($ip);

$hash = $_GET['hash'];

$base64 = $_GET['base64'];

$folder = "files";

$folder_user = "users";

//Avoid the users use the symbol reserved for temporary files
$hash = str_replace("_","",$hash);

$base64 = str_replace(" ","+",$base64);

//Already exist files cannot be overwrite
if(file_exists("$folder/$hash")){

    echo "File already exists.";

    }else{

    //Open and write temporary file
    $base64_file = fopen("$folder/tmp_$hash", "a");
    fwrite($base64_file, $base64);
    fclose($base64_file);

}

$last_hash = file_get_contents("$folder_user/$ip_hash");
    
if($last_hash != "tmp_$hash"){

    $wallet = $_GET['wallet'];
    $category = $_GET['category'];
    $redirect = $_GET['redirect'];
    
    $filename =  substr($last_hash, 4);
    rename("$folder/$last_hash", "$folder/$filename");

    $last = fopen("$folder_user/$ip_hash", "w");
    fwrite($last, "tmp_$hash");
    fclose($last);

    include("sql/conf.php");

    $day = date("d");

    $month = date("m");

    $year = date("y");



    
    $date = $year . $day . $month ;

    $base64_content = file_get_contents("$folder/$filename");

    $query = "INSERT INTO 64pic (hash, wallet, base64, date, category, redirect) VALUES ('$filename', '$wallet', '$base64_content', '$date', '$category', '$redirect')";

    $result = mysqli_query($db, $query);   

}

?>