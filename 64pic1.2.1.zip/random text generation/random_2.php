<?php

$c = array('b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z');
$v = array('a', 'e', 'i', 'o', 'u');

for ($i = 0; $i < 1000; $i++){

    $general = rand(0, 100);
    $random_c = rand(0, 20);
    $random_v = rand(0, 4);
    $random_space = rand(0, 100);

    if ($random_space > 50){$space = ' ';} else {$space = '';} 
   
    if($general > 50){echo $c[$random_c] . $space . $v[$random_v];}
    if($general < 50){echo $v[$random_v] . $space . $c[$random_c];}
    if($general > 99){echo $c[$random_c] . $c[$random_c] . $space . $v[$random_v];}
    if($general > 95){echo $c[$random_c] . $space . $v[$random_v] . $v[$random_v];} 
}

?>