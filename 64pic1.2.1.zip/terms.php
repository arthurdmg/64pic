﻿<!doctype html>
<html>

  <head>

    <meta charset='utf-8'>

    <link rel="icon" href="logos/2.png">
    <link rel="stylesheet" href="default.css">
    <script src="js/default.js"></script>

    <title>64pic</title>
  </head>
<body>

<table width="100%">
<tr>
<td>
<img src='logos/background2.jpg' width='100%'><br><br>
<div align='center'>
<img src='logos/1.png'
</div>
</td>
</tr>
</table>

  <table width="100%" style="padding-left: 15%; padding-right: 15%; text-align: justify;" border="0">
    <tr>
      <td> 

      <h1>Termos de uso</h1>

      <p style='letter-spacing: 2px;'>O 64pic é um sistema de armazenamento distribuido que não se responsabiliza pelo conteúdo postado por terceiros. 

      <br><br>

      64pic is a distributed storage system that is not responsible for content posted by third parties.

<div align='center'><a href='index.php'>voltar</a></div>
<br>
<br>

  </body>
</html>